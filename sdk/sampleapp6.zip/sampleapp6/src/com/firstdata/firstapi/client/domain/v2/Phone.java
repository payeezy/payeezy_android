package com.firstdata.firstapi.client.domain.v2;
/*
import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = Visibility.ANY, getterVisibility = Visibility.ANY, setterVisibility = Visibility.ANY)
public class Phone
{
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("number")
	private String number;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("type")
	private String type;
	
	public String getNumber ()
	{
	return number;
	}
	
	public void setNumber (String number)
	{
	this.number = number;
	}
	
	public String getType ()
	{
	return type;
	}
	
	public void setType (String type)
	{
	this.type = type;
	}
	
}
*/
