package com.example.sampleapp6;

import com.firstdata.firstapi.client.domain.v2.ValueLinkCard;

public class TransactionDataProviderVL extends TransactionDataProviderBase{

	public ValueLinkCard vlcard = new ValueLinkCard();

	public TransactionDataProviderVL()
	{
		vlcard.setCc_number("7777045839985463");
		vlcard.setCardholder_name("Joe Smith");
		vlcard.setCredit_card_type("Gift");
		vlcard.setCredit_card_type("5");
	}
	public  String appId = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
	public  String secureId = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
	public  String token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
	public  String url = "https://api-cert.payeezy.com/v1";
	
	public  String Amount = "1100";
	public  String Currency ="USD";
	public  String Method ="credit_card";
	public  String TransactionType = "AUTHORIZE";
    
	
	public  String Cvv = "123";
	public  String ExpiryDt = "1216";
	public  String Name = "Test data ";
	public  String Type = "visa";
    
	public  String Number = "4012000033330026";
    public  String State = "NY";
	public  String AddressLine1 = "sss";
	public  String Zip ="11747";
	public  String Country = "US";

	public  String secPaymentMethod = "credit_card";
	public  String secAmount = "1100";
	public  String secCurrency = "USD";
	public  String secTransactionTag = "349990997";
	public  String secTransactionId = "07698G";
	
	public  String secAppId = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
	public  String secSecureId = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
	public  String secToken = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";

	public  String voidAmount = "1100";
	public  String voidCurrency ="USD";
	public  String voidMethod ="valuelink";
	public  String voidTransactionType = "AUTHORIZE";
    
	public  String voidCvv = "123";
	public  String voidExpiryDt = "1216";
	public  String voidName = "Test data ";
	public  String voidType = "prepaid_gift_card";
    
	public  String voidNumber = "4012000033330026";
    public  String voidState = "NY";
	public  String voidAddressLine1 = "sss";
	public  String voidZip ="11747";
	public  String voidCountry = "US";

	
}
