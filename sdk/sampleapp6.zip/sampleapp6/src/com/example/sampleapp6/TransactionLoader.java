package com.example.sampleapp6;


public class TransactionLoader {

	//List<TransactionRequest> requests = new ArrayList<TransactionRequest>();
	public void LoadTransactions()
	{
		
	}
}
