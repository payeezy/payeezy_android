package com.example.sampleapp6;


public class TransactionDataProvider {

	//public static String appIdCert = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
	//public static String secureIdCert = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
	//public static String tokenCert = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
	//public static String urlCert = "https://api-cert.payeezy.com/v1";
	
	public static String appId = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
	public static String secureId = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
	public static String token = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
	public static String url = "https://api-cat.payeezy.com/v1";
	
	//public static String appIdCat = "bA8hIqpzuAVW6itHqXsXwSl6JtFWPCA0";
	//public static String secureIdCat = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
	//public static String tokenCat = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
	//public static String urlCat = "https://api-cat.payeezy.com/v1";
	
	public static String appIdCat = "bA8hIqpzuAVW6itHqXsXwSl6JtFWPCA0";
	public static String secureIdCat = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
	public static String tokenCat = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
	public static String urlCat = "https://api-cat.payeezy.com/v1";
	
	//public static String appIdValueLink = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
	//public static String secureIdValueLink = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
	//public static String tokenValueLink = "fdoa-a480ce8951daa73262734cf102641994abc7643456k02b6";
	
	public static String appIdValueLink = "bA8hIqpzuAVW6itHqXsXwSl6JtFWPCA0";
	public static String secureIdValueLink = "675d92bff9602acb6a52cbf7529f34c923689b60a65734f33c1917b196b13036";
	//public static String tokenValueLink = "fdoa-a480ce8951daa73262734cf102641994abc7643456k02b6";
	public static String tokenValueLink = "fdoa-a480ce8951daa73262734cf102641994abc7643456k02b6";
	//fdoa-a480ce8951daa73262734cf102641994abc7643456k02b6	

	
	public static String appIdTelecheck = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
	public static String secureIdTelecheck = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
	public static String tokenTelecheck = "fdoa-a480ce8951daa73262734cf102641994abc7643456k02b6";
	
	public static String appIdCert = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
	public static String secureIdCert = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
	public static String tokenCert = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
	public static String urlCert = "https://api-cert.payeezy.com/v1";
	
	public static String appIdInt = "C5VAeX3WwStH0ZDnlF4eXVhHJiIedDtY";
	public static String secureIdInt = "2b940ece234ee38131e70cc617aa2afa3d7ff8508856917958e7feb3ef190447";
	public static String tokenInt = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";
	public static String merchantidInt ="OGEzNGU3NjM0ODQyMTU3NzAxNDg0MjE4NDY4ZTAwMDA=";
	public static String trTokenInt = "y6pzAbc3Def123"; 
	public static String urlInt = "https://api-int.payeezy.com/v1";
	
	
	public static String  Amount = "1100";
	public static String  AmountReload = "2500";
	public static String Currency ="USD";
	public static String Method ="credit_card";
	public static String TransactionType = "AUTHORIZE";
    
	public static String Cvv = "123";
	public static String ExpiryDt = "1216";
	public static String Name = "Test data ";
	public static String Type = "visa";
    
	public static String Number = "4012000033330026";
    public static String State = "NY";
	public static String AddressLine1 = "sss";
	public static String Zip ="11747";
	public static String Country = "US";

	public static String secPaymentMethod = "credit_card";
	public static String secAmount = "1100";
	public static String secCurrency = "USD";
	public static String secTransactionTag = "349990997";
	public static String secTransactionId = "07698G";
	
	public static String secAppId = "y6pWAJNyJyjGv66IsVuWnklkKUPFbb0a";
	public static String secSecureId = "86fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f786fbae7030253af3cd15faef2a1f4b67353e41fb6799f576b5093ae52901e6f7";
	public static String secToken = "fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6";

	public static String voidAmount = "1100";
	public static String voidCurrency ="USD";
	public static String voidMethod ="credit_card";
	public static String voidTransactionType = "AUTHORIZE";
    
	public static String voidCvv = "123";
	public static String voidExpiryDt = "1216";
	public static String voidName = "Test data ";
	public static String voidType = "visa";
    
	public static String voidNumber = "4012000033330026";
    public static String voidState = "NY";
	public static String voidAddressLine1 = "sss";
	public static String voidZip ="11747";
	public static String voidCountry = "US";

	
}
